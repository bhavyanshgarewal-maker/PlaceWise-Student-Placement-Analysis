import re
from pathlib import Path
import plotly.graph_objects as go
import plotly.express as px
import matplotlib.pyplot as plt
import streamlit as st
import etl
import model as mdl

st.set_page_config(page_title="PlaceWise — Placement Intelligence", page_icon="◧", layout="wide")
INDIGO, TEAL, INK, MUTED, LINE = "#5B5FEF", "#14B8A6", "#172033", "#687386", "#E5E7EB"

def html(s):
    st.markdown(re.sub(r"\n\s*", "", s), unsafe_allow_html=True)

html(f"<style>{(Path(__file__).parent / 'styles.css').read_text()}</style>")

st.sidebar.title("PlaceWise Navigation")
st.sidebar.caption("DWDM · Student Placement Analytics")
st.sidebar.markdown("### Compare: J48 vs Naive Bayes")
st.sidebar.markdown("Includes regression and clustering in the same comparison window.")
nav_choice = st.sidebar.radio("Project modules", ["All-model comparison", "Placement predictor", "Data quality & warehouse"], index=0)
st.sidebar.markdown("---")
st.sidebar.caption("Synthetic demonstration data · 60,000 raw records")

# ---------- data (ETL on first run) ----------
if not etl.DB.exists():
    with st.spinner("Running ETL and building the warehouse…"):
        etl.run_etl()

@st.cache_data
def q(sql, stamp):
    return etl.query(sql)

stamp = etl.DB.stat().st_mtime if etl.DB.exists() else 0
total = q("SELECT COUNT(*) n, SUM(placed) p, AVG(salary_lpa) s FROM vw_students", stamp).iloc[0]
n, placed = int(total.n or 0), int(total.p or 0)
st.sidebar.metric("Clean warehouse records", f"{n:,}")
has_salary = total.s == total.s and total.s is not None  # not NaN

@st.cache_resource
def get_all_models(stamp):
    return mdl.train_all() if n > 0 else None
all_models = get_all_models(stamp)
bundle = all_models["j48"] if all_models else None

def style(fig, h=300):
    fig.update_layout(height=h, margin=dict(l=8, r=8, t=8, b=8), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", font=dict(family="Inter, system-ui", color=INK, size=12),
                      showlegend=False, bargap=.35)
    fig.update_xaxes(showgrid=False, linecolor=LINE, tickfont=dict(color=MUTED))
    fig.update_yaxes(gridcolor=LINE, zeroline=False, ticksuffix="%", range=[0, 105], tickfont=dict(color=MUTED))
    return fig

def rate_bar(df, x, color):
    fig = go.Figure(go.Bar(x=df[x], y=df["rate"], marker_color=color, text=df["rate"].map("{:.0f}%".format),
                           textposition="outside", cliponaxis=False,
                           customdata=df[["n"]], hovertemplate="%{x}<br>%{y:.1f}% placed · %{customdata[0]} students<extra></extra>"))
    return style(fig)

def section(num, name):
    html(f'<div class="sec">{num} / {name}</div>')

# ---------- nav + hero ----------
html("""
<div class="nav">
<svg width="26" height="26" viewBox="0 0 26 26"><rect width="26" height="26" rx="7" fill="#5B5FEF"/><rect x="6" y="13" width="4" height="7" rx="1" fill="#fff"/><rect x="11" y="9" width="4" height="11" rx="1" fill="#fff"/><circle cx="19" cy="9" r="2.5" fill="#14B8A6"/></svg>
<span class="brand">placewise</span><span class="tag">PLACEMENT INTELLIGENCE</span><span class="badge">DWDM PROJECT</span>
</div>
<div class="hero"><div>
<div class="eyebrow">STUDENT OUTCOME ANALYTICS</div>
<h1>Understand placements. Discover patterns.</h1>
<p>PlaceWise turns raw student records into a queryable warehouse and a trained model, so academic and experience signals become clear, actionable insights.</p>
</div>
<div class="dots"><i style="left:30px;top:100px"></i><i class="t" style="left:78px;top:70px"></i><i style="left:112px;top:84px"></i><i class="t" style="left:150px;top:40px"></i><i style="left:186px;top:22px"></i></div>
</div>
""")

if n == 0:
    html('<div class="empty">No student records found. Add <code>data/placement_data.csv</code> and run <code>python etl.py</code>.</div>')
    st.stop()

# ---------- 01 overview ----------
section("01", "OVERVIEW")
ICON = {"users": '<path d="M16 19v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M9 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM22 19v-1a4 4 0 0 0-3-3.8M16 4.2a3 3 0 0 1 0 5.6"/>',
        "check": '<path d="M20 6 9 17l-5-5"/>', "pct": '<path d="M19 5 5 19M7 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM17 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/>',
        "coin": '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9.5 9.5c0-1 1-1.5 2.5-1.5s2.5.6 2.5 1.7c0 2.3-5 1.2-5 3.6 0 1.1 1 1.7 2.5 1.7s2.5-.5 2.5-1.5"/>'}
cards = [("Total Students", f"{n:,}", "users", ""), ("Students Placed", f"{placed:,}", "check", "t"),
         ("Placement Rate", f"{placed / n * 100:.1f}%", "pct", "a")]
if has_salary:
    cards.append(("Average Salary", f"₹{total.s:.2f} LPA", "coin", ""))
for col, (l, v, ic, c) in zip(st.columns(len(cards)), cards):
    with col:
        html(f'<div class="kpi {c}"><div class="l">{l}<svg viewBox="0 0 24 24">{ICON[ic]}</svg></div><div class="v">{v}</div></div>')

# ---------- 02 analytics ----------
section("02", "ANALYTICS")
dept = q("""SELECT department, COUNT(*) n, 100.0*SUM(placed)/COUNT(*) rate
            FROM vw_students GROUP BY department ORDER BY rate DESC""", stamp)
band = q("""SELECT CASE WHEN cgpa<6 THEN '<6.0' WHEN cgpa<7 THEN '6.0–6.9' WHEN cgpa<8 THEN '7.0–7.9'
            WHEN cgpa<9 THEN '8.0–8.9' ELSE '9.0+' END band, COUNT(*) n, 100.0*SUM(placed)/COUNT(*) rate
            FROM vw_students GROUP BY band""", stamp)
band["order"] = band["band"].map({b: i for i, b in enumerate(["<6.0", "6.0–6.9", "7.0–7.9", "8.0–8.9", "9.0+"])})
band = band.sort_values("order")
intern = q("""SELECT MIN(internships,3) k, COUNT(*) n, 100.0*SUM(placed)/COUNT(*) rate
              FROM vw_students GROUP BY k ORDER BY k""", stamp)
intern["label"] = intern["k"].map(lambda k: "3+" if k == 3 else str(int(k)))

c1, c2 = st.columns(2)
with c1, st.container(border=True):
    html('<p class="ct">Placement rate by department</p><p class="cap">Which branches convert the most students into offers.</p>')
    st.plotly_chart(rate_bar(dept, "department", INDIGO), use_container_width=True, config={"displayModeBar": False})
c3, c4 = st.columns(2)
with c3, st.container(border=True):
    html('<p class="ct">CGPA vs placement</p><p class="cap">Placement rate climbs as CGPA bands rise, though the gap narrows at the top.</p>')
    st.plotly_chart(rate_bar(band, "band", TEAL), use_container_width=True, config={"displayModeBar": False})
with c4, st.container(border=True):
    html('<p class="ct">Internships vs placement</p><p class="cap">Placement rate by number of internships completed.</p>')
    st.plotly_chart(rate_bar(intern, "label", TEAL), use_container_width=True, config={"displayModeBar": False})

# ---------- 03 prediction ----------
section("03", "PREDICTION")
depts = sorted(dept["department"])
with st.container(border=True):
    html('<span class="pill">DECISION TREE</span><p class="ct" style="font-size:1.25rem;margin-top:10px">Placement Predictor</p>'
         '<p class="cap">Enter a student profile to estimate placement likelihood.</p>')
    left, right = st.columns([1.1, 1])
    with left:
        with st.form("predictor"):
            a, b = st.columns(2)
            cgpa = a.number_input("CGPA", 0.0, 10.0, 7.5, 0.1)
            department = b.selectbox("Department", depts)
            a, b = st.columns(2)
            internships = a.number_input("Internships", 0, 10, 1)
            projects = b.number_input("Projects", 0, 20, 2)
            a, b = st.columns(2)
            backlogs = a.number_input("Active backlogs", 0, 20, 0)
            comm = b.slider("Communication score", 1, 10, 7)
            go_btn = st.form_submit_button("Analyze Student Profile", type="primary")
    with right:
        if go_btn:
            ok, p = mdl.predict(bundle, dict(cgpa=cgpa, internships=internships, projects=projects,
                                             backlogs=backlogs, communication_score=comm, department=department))
            cls, title = ("yes", "Likely to be placed") if ok else ("no", "Less likely to be placed")
            html(f'<div class="res {cls}"><span class="tag">PREDICTED OUTCOME</span><div class="o">{title}</div>'
                 f'<div class="cap">Estimated placement probability: <b>{p * 100:.1f}%</b></div>'
                 f'<div class="bar"><b style="width:{p * 100:.0f}%"></b></div>'
                 f'<div class="note">This is a statistical estimate from past data, not a placement guarantee.</div></div>')
        else:
            html('<div class="res"><span class="tag">PREDICTED OUTCOME</span><div class="o" style="color:#687386">Awaiting profile</div>'
                 '<div class="note">Fill in the form and press <b>Analyze Student Profile</b>. Predictions are estimates, not guarantees.</div></div>')
    top = ", ".join(f"{k.replace('_', ' ')} ({v * 100:.0f}%)" for k, v in bundle["importance"].head(3).items())
    html(f'<p class="cap">Model accuracy on held-out test data: <b>{bundle["accuracy"] * 100:.1f}%</b> '
         f'({bundle["n_test"]} test students). Most influential features: {top}.</p>')



# ---------- 04 model lab and comparison ----------
section("04", "DATA MINING MODEL LAB")
html('<p class="cap">Five complementary data-mining approaches. Classification scores are measured on held-out records; regression, association, and clustering use task-specific metrics.</p>')

j48 = all_models["j48"]
nb = all_models["naive_bayes"]
reg = all_models["regression"]
ap = all_models["apriori"]
km = all_models["kmeans"]

# At-a-glance recommendation: compare models only against metrics appropriate to their task.
with st.container(border=True):
    st.markdown(f"### Recommended placement classifier: **{all_models['recommended']}**")
    st.write(all_models["recommendation_reason"])
    st.caption("This recommendation is for predicting the placed / not-placed outcome. Regression, Apriori, and K-Means answer different questions, so their scores should not be ranked against classification accuracy.")

metric_rows = [
    {"Model": "J48 Decision Tree", "Task": "Classification", "Primary metric": "Accuracy", "Score": f"{j48['metrics']['Accuracy']:.1%}", "Other result": f"F1 {j48['metrics']['F1 score']:.1%}"},
    {"Model": "Naive Bayes", "Task": "Classification", "Primary metric": "Accuracy", "Score": f"{nb['metrics']['Accuracy']:.1%}", "Other result": f"F1 {nb['metrics']['F1 score']:.1%}"},
    {"Model": "Multiple Linear Regression", "Task": "Salary prediction", "Primary metric": "R²", "Score": f"{reg['metrics'].get('R²', float('nan')):.3f}" if reg["available"] else "N/A", "Other result": f"MAE ₹{reg['metrics']['MAE (LPA)']:.2f} LPA" if reg["available"] else "Insufficient salary records"},
    {"Model": "Apriori Association", "Task": "Pattern discovery", "Primary metric": "Rules found", "Score": str(ap["metrics"]["Rules found"]), "Other result": f"Top lift {ap['metrics']['Top lift']:.2f}" if pd.notna(ap["metrics"]["Top lift"]) else "No rules met thresholds"},
    {"Model": "K-Means Clustering", "Task": "Student segmentation", "Primary metric": "Silhouette", "Score": f"{km['silhouette']:.3f}" if pd.notna(km["silhouette"]) else "N/A", "Other result": f"{km['n_clusters']} clusters"},
]
st.dataframe(pd.DataFrame(metric_rows), use_container_width=True, hide_index=True)

# Single-window comparison: all four requested models, definitions, metrics, and diagrams.
st.markdown("## Compare: J48 vs Naive Bayes")
st.caption("Regression and clustering are included in the same comparison. Accuracy, precision, recall and F1 are classification metrics, so they are not applicable to regression or clustering; those models are judged with their own valid metrics.")

compare = pd.DataFrame([
 {"Model":"J48 Decision Tree", "Type":"Classification", "Accuracy":j48["metrics"]["Accuracy"], "Precision":j48["metrics"]["Precision"], "Recall":j48["metrics"]["Recall"], "F1 score":j48["metrics"]["F1 score"], "Task-specific result":"Placement yes/no"},
 {"Model":"Naive Bayes", "Type":"Classification", "Accuracy":nb["metrics"]["Accuracy"], "Precision":nb["metrics"]["Precision"], "Recall":nb["metrics"]["Recall"], "F1 score":nb["metrics"]["F1 score"], "Task-specific result":"Placement yes/no"},
 {"Model":"Multiple Linear Regression", "Type":"Regression", "Accuracy":np.nan, "Precision":np.nan, "Recall":np.nan, "F1 score":np.nan, "Task-specific result":f"R² {reg['metrics'].get('R²', float('nan')):.3f} · MAE ₹{reg['metrics'].get('MAE (LPA)', float('nan')):.2f} LPA" if reg["available"] else "Insufficient salary records"},
 {"Model":"K-Means Clustering", "Type":"Clustering", "Accuracy":np.nan, "Precision":np.nan, "Recall":np.nan, "F1 score":np.nan, "Task-specific result":f"Silhouette {km['silhouette']:.3f} · {km['n_clusters']} clusters" if pd.notna(km["silhouette"]) else f"{km['n_clusters']} clusters"},
])
view = compare.copy()
for metric in ["Accuracy", "Precision", "Recall", "F1 score"]:
    view[metric] = view[metric].map(lambda x: f"{x:.1%}" if pd.notna(x) else "N/A — not a classification metric")
st.dataframe(view, use_container_width=True, hide_index=True)

left, right = st.columns(2, gap="large")
with left, st.container(border=True):
    st.markdown("### 1. J48 Decision Tree")
    st.write("**Definition:** A tree-based classifier that chooses feature splits using information gain/gain ratio. The leaves predict placed or not placed. This is an entropy-based J48-style tree, not WEKA's exact implementation.")
    for metric in ["Accuracy", "Precision", "Recall", "F1 score"]: st.metric(metric, f"{j48['metrics'][metric]:.1%}")
    fig, ax = plt.subplots(figsize=(12, 5))
    mdl_tree = j48["pipe"].named_steps["model"]
    feature_names = j48["pipe"].named_steps["pre"].get_feature_names_out()
    from sklearn.tree import plot_tree
    plot_tree(mdl_tree, feature_names=[str(x).replace("dept__", "").replace("remainder__", "") for x in feature_names], class_names=["Not placed", "Placed"], filled=True, rounded=True, max_depth=3, fontsize=7, ax=ax)
    ax.set_title("J48-style decision tree (first 3 levels shown)")
    st.pyplot(fig, use_container_width=True); plt.close(fig)
    imp = j48["importance"].rename_axis("Feature").reset_index(name="Importance").head(8)
    st.plotly_chart(px.bar(imp, x="Importance", y="Feature", orientation="h", title="Most influential features").update_layout(height=280, yaxis={"categoryorder":"total ascending"}), use_container_width=True)

with right, st.container(border=True):
    st.markdown("### 2. Naive Bayes")
    st.write("**Definition:** A probabilistic classifier applying Bayes' theorem and assuming features are conditionally independent given the class. It is fast and works as a useful baseline.")
    for metric in ["Accuracy", "Precision", "Recall", "F1 score"]: st.metric(metric, f"{nb['metrics'][metric]:.1%}")
    st.markdown("**Probability flow**")
    st.code("""Student features
      ↓
Prior placement probability P(class)
      +
Feature likelihoods P(feature | class)
      ↓
Bayes posterior P(class | features)
      ↓
Placed / Not placed""", language="text")
    nb_counts = pd.DataFrame({"Metric":["Accuracy","Precision","Recall","F1 score"], "J48":[j48["metrics"][m] for m in ["Accuracy","Precision","Recall","F1 score"]], "Naive Bayes":[nb["metrics"][m] for m in ["Accuracy","Precision","Recall","F1 score"]]})
    st.plotly_chart(px.bar(nb_counts, x="Metric", y=["J48","Naive Bayes"], barmode="group", title="Classification metrics comparison", labels={"value":"Score","variable":"Model"}).update_layout(height=300, yaxis_tickformat=".0%"), use_container_width=True)

with left, st.container(border=True):
    st.markdown("### 3. Multiple Linear Regression")
    st.write("**Definition:** Estimates a continuous value (here, salary in LPA) from several input variables by fitting a linear relationship.")
    if reg["available"]:
        a,b,c=st.columns(3); a.metric("R²", f"{reg['metrics']['R²']:.3f}"); b.metric("MAE", f"₹{reg['metrics']['MAE (LPA)']:.2f}"); c.metric("RMSE", f"₹{reg['metrics']['RMSE (LPA)']:.2f}")
        salary_eval = reg["pipe"].predict(reg["X_test"]) if "X_test" in reg else None
        st.code("""CGPA ─┐
Internships ─┤
Projects ────┼─> Linear equation ─> Estimated salary (LPA)
Backlogs ────┤
Department ──┘""", language="text")
        if salary_eval is not None:
            reg_plot = pd.DataFrame({"Actual salary (LPA)":reg["y_test"].to_numpy(), "Predicted salary (LPA)":salary_eval})
            st.plotly_chart(px.scatter(reg_plot, x="Actual salary (LPA)", y="Predicted salary (LPA)", title="Actual vs predicted salary"), use_container_width=True)
        else:
            st.caption("Regression quality is summarized by R², MAE and RMSE; classification metrics are not applicable.")
    else: st.warning("Regression requires enough placed students with valid salary_lpa values.")
    st.info("Accuracy / precision / recall / F1: N/A. Use R² (higher is generally better) and MAE/RMSE (lower is better).")

with right, st.container(border=True):
    st.markdown("### 4. K-Means Clustering")
    st.write("**Definition:** An unsupervised algorithm that groups students into K clusters according to similarity in numeric profile features. Placement outcome is not used to form the clusters.")
    a,b=st.columns(2); a.metric("Clusters", km["n_clusters"]); b.metric("Silhouette score", f"{km['silhouette']:.3f}" if pd.notna(km["silhouette"]) else "N/A")
    st.code("""Choose K cluster centres
        ↓
Assign each student to nearest centre
        ↓
Recalculate cluster centres
        ↓
Repeat until assignments stabilize""", language="text")
    cluster_show = km["summary"].copy()
    st.plotly_chart(px.bar(cluster_show, x="cluster", y="Students", color="cluster", title="Students per cluster"), use_container_width=True)
    st.dataframe(cluster_show.round(2), use_container_width=True, hide_index=True)
    st.info("Accuracy / precision / recall / F1: N/A without ground-truth cluster labels. Silhouette closer to 1 generally indicates better-separated clusters.")

st.markdown("### Definitions and metric guide")
st.dataframe(pd.DataFrame([
 {"Metric":"Accuracy", "Meaning":"Correct predictions / all predictions", "Applicable models":"J48, Naive Bayes"},
 {"Metric":"Precision", "Meaning":"Of students predicted placed, fraction actually placed", "Applicable models":"J48, Naive Bayes"},
 {"Metric":"Recall", "Meaning":"Of actually placed students, fraction correctly identified", "Applicable models":"J48, Naive Bayes"},
 {"Metric":"F1 score", "Meaning":"Harmonic mean of precision and recall", "Applicable models":"J48, Naive Bayes"},
 {"Metric":"R² / MAE / RMSE", "Meaning":"Regression fit and prediction error", "Applicable models":"Multiple Linear Regression"},
 {"Metric":"Silhouette score", "Meaning":"How well-separated and cohesive clusters are", "Applicable models":"K-Means"},
]), use_container_width=True, hide_index=True)
st.success(f"Best model for placement classification on this dataset: {all_models['recommended']}. {all_models['recommendation_reason']}")
st.caption("Recommendation is task-specific: J48 and Naive Bayes predict placement; regression predicts salary; K-Means segments profiles. These different tasks should not be ranked using one shared score.")

section("05", "DEPARTMENT-WISE COMPARISON")
st.caption("For each department, this compares J48 and Naive Bayes accuracy on the same held-out test records. Small department test groups can make these estimates unstable.")
if not all_models["department_comparison"].empty:
    dc = all_models["department_comparison"].copy()
    for col in ["J48 accuracy", "Naive Bayes accuracy"]:
        dc[col] = dc[col].map(lambda x: f"{x:.1%}")
    st.dataframe(dc, use_container_width=True, hide_index=True)
else:
    st.info("Not enough held-out records per department for a meaningful department-wise comparison.")


# ---------- 06 pipeline ----------
section("06", "DATA PIPELINE")
steps = [("CSV Dataset", "Raw student records"), ("ETL Processing", "Clean, validate, encode"),
         ("SQLite Warehouse", f"{n:,} facts · {len(depts)} departments"), ("Data Mining", "Five complementary models"),
         ("Insights", f"{bundle['accuracy'] * 100:.0f}% J48 test accuracy")]
html('<div class="pipe">' + '<span class="arr">→</span>'.join(
    f'<div class="step{" last" if i == 4 else ""}"><b>{a}</b><span>{b}</span></div>' for i, (a, b) in enumerate(steps)) + '</div>')

html('<div class="foot">PlaceWise · A DWDM project demonstrating ETL, SQL analytics, classification, regression, association rules, and clustering.</div>')
