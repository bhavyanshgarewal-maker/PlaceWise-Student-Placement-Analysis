"""PlaceWise data-mining models: J48-style tree, Naive Bayes, regression, Apriori, K-Means."""
from itertools import combinations
import math
import warnings

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             mean_absolute_error, mean_squared_error, r2_score, silhouette_score)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from etl import query

NUMERIC = ["cgpa", "internships", "projects", "backlogs", "communication_score"]
FEATURES = NUMERIC + ["department"]


def _classification_bundle(df, kind):
    X, y = df[FEATURES].copy(), df["placed"].astype(int)
    stratify = y if y.value_counts().min() >= 2 else None
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=stratify)
    pre = ColumnTransformer([("dept", OneHotEncoder(handle_unknown="ignore"), ["department"])], remainder="passthrough")
    estimator = (DecisionTreeClassifier(criterion="entropy", max_depth=5, min_samples_leaf=5, random_state=42)
                 if kind == "j48" else GaussianNB())
    pipe = Pipeline([("pre", pre), ("model", estimator)])
    pipe.fit(Xtr, ytr)
    pred = pipe.predict(Xte)
    metrics = {
        "Accuracy": accuracy_score(yte, pred),
        "Precision": precision_score(yte, pred, zero_division=0),
        "Recall": recall_score(yte, pred, zero_division=0),
        "F1 score": f1_score(yte, pred, zero_division=0),
        "Test records": int(len(yte)),
    }
    importance = pd.Series(dtype=float)
    if kind == "j48":
        names = pipe.named_steps["pre"].get_feature_names_out()
        names = [x.split("__", 1)[-1] for x in names]
        names = ["department" if x.startswith("department_") else x for x in names]
        importance = pd.Series(pipe.named_steps["model"].feature_importances_, index=names).groupby(level=0).sum().sort_values(ascending=False)
    return {"pipe": pipe, "metrics": metrics, "accuracy": metrics["Accuracy"], "importance": importance,
            "n_train": len(ytr), "n_test": len(yte), "y_test": yte, "pred_test": pd.Series(pred, index=yte.index)}


def _transactions(df):
    rows = []
    for _, r in df.iterrows():
        cgpa_band = "CGPA: below 7" if r.cgpa < 7 else ("CGPA: 7 to below 8" if r.cgpa < 8 else "CGPA: 8+")
        intern_band = "Internships: 0" if r.internships == 0 else ("Internships: 1" if r.internships == 1 else "Internships: 2+")
        project_band = "Projects: 0-1" if r.projects <= 1 else ("Projects: 2-3" if r.projects <= 3 else "Projects: 4+")
        backlog_band = "Backlogs: 0" if r.backlogs == 0 else "Backlogs: 1+"
        rows.append({f"Department: {r.department}", cgpa_band, intern_band, project_band, backlog_band,
                     "Placed" if int(r.placed) == 1 else "Not placed"})
    return rows


def _apriori(df, min_support=0.08, min_confidence=0.55, max_len=3):
    transactions = _transactions(df)
    n = len(transactions)
    if not n:
        return pd.DataFrame(columns=["Rule", "Support", "Confidence", "Lift"]), []
    item_counts = {}
    for row in transactions:
        for item in row:
            item_counts[frozenset([item])] = item_counts.get(frozenset([item]), 0) + 1
    frequent = {s: c for s, c in item_counts.items() if c / n >= min_support}
    all_freq = dict(frequent)
    for size in range(2, max_len + 1):
        prev = [s for s in frequent if len(s) == size - 1]
        candidates = set()
        for i in range(len(prev)):
            for j in range(i + 1, len(prev)):
                joined = prev[i] | prev[j]
                if len(joined) == size:
                    candidates.add(joined)
        counts = {}
        for cand in candidates:
            if all((cand - {item}) in frequent for item in cand):
                counts[cand] = sum(cand.issubset(row) for row in transactions)
        frequent = {s: c for s, c in counts.items() if c / n >= min_support}
        all_freq.update(frequent)
        if not frequent:
            break
    support_map = {s: c / n for s, c in all_freq.items()}
    rules = []
    for itemset, sup_count in all_freq.items():
        if len(itemset) < 2:
            continue
        for r in range(1, len(itemset)):
            for antecedent_items in combinations(itemset, r):
                antecedent = frozenset(antecedent_items)
                consequent = itemset - antecedent
                ant_support = support_map.get(antecedent, 0)
                cons_support = support_map.get(consequent, 0)
                confidence = support_map[itemset] / ant_support if ant_support else 0
                lift = confidence / cons_support if cons_support else 0
                if confidence >= min_confidence:
                    rules.append({"Rule": " + ".join(sorted(antecedent)) + "  →  " + " + ".join(sorted(consequent)),
                                  "Support": support_map[itemset], "Confidence": confidence, "Lift": lift})
    result = pd.DataFrame(rules)
    if not result.empty:
        result = result.sort_values(["Lift", "Confidence", "Support"], ascending=False).drop_duplicates("Rule").head(30)
    return result, sorted(((tuple(sorted(s)), c / n) for s, c in all_freq.items()), key=lambda x: (-x[1], x[0]))


def train_all():
    """Train all five approaches and return their fitted objects, metrics and outputs."""
    df = query("SELECT * FROM vw_students")
    if df.empty:
        raise ValueError("No student rows exist in the warehouse. Run ETL first.")
    # Keep a valid binary target and finite numeric features.
    df = df.dropna(subset=FEATURES + ["placed"]).copy()
    df["placed"] = df["placed"].astype(int)
    if df["placed"].nunique() < 2 or len(df) < 10:
        raise ValueError("At least 10 student records and both placement outcomes are needed to compare models.")

    j48 = _classification_bundle(df, "j48")
    nb = _classification_bundle(df, "nb")

    # Multiple linear regression estimates salary among placed students with recorded salary.
    salary_df = df.dropna(subset=["salary_lpa"])
    regression = {"available": False, "metrics": {}, "pipe": None}
    if len(salary_df) >= 10 and salary_df["salary_lpa"].nunique() > 1:
        X, y = salary_df[FEATURES], salary_df["salary_lpa"].astype(float)
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)
        pre = ColumnTransformer([("dept", OneHotEncoder(handle_unknown="ignore"), ["department"])], remainder="passthrough")
        pipe = Pipeline([("pre", pre), ("scale", StandardScaler(with_mean=False)), ("model", LinearRegression())])
        pipe.fit(Xtr, ytr)
        pred = pipe.predict(Xte)
        regression = {"available": True, "pipe": pipe, "metrics": {
            "R²": float(r2_score(yte, pred)) if len(yte) > 1 else float("nan"),
            "MAE (LPA)": float(mean_absolute_error(yte, pred)),
            "RMSE (LPA)": float(math.sqrt(mean_squared_error(yte, pred))),
            "Test records": int(len(yte))}, "n_train": len(ytr), "n_test": len(yte), "y_test": yte.reset_index(drop=True), "pred_test": np.asarray(pred)}

    # K-Means groups similar student profiles; placement is deliberately excluded from clustering inputs.
    cluster_features = df[NUMERIC].astype(float)
    scaler = StandardScaler()
    scaled = scaler.fit_transform(cluster_features)
    k = min(3, max(2, len(df) // 10))
    k = min(k, len(df) - 1)
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(scaled)
    sil = float(silhouette_score(scaled, labels, sample_size=min(5000, len(df)), random_state=42)) if len(set(labels)) > 1 and len(df) > k else float("nan")
    cluster_summary = df.assign(cluster=labels).groupby("cluster").agg(
        Students=("student_id", "count"), Placement_Rate=("placed", "mean"),
        Average_CGPA=("cgpa", "mean"), Average_Internships=("internships", "mean"),
        Average_Projects=("projects", "mean")).reset_index()
    cluster_summary["Placement_Rate"] *= 100
    kmeans = {"pipe": km, "scaler": scaler, "labels": labels, "silhouette": sil,
              "n_clusters": k, "summary": cluster_summary, "metrics": {"Silhouette score": sil, "Clusters": k}}

    rules, itemsets = _apriori(df.sample(n=min(12000, len(df)), random_state=42))
    apriori = {"rules": rules, "itemsets": itemsets, "metrics": {
        "Frequent itemsets": len(itemsets), "Rules found": len(rules),
        "Top lift": float(rules["Lift"].max()) if not rules.empty else float("nan")}}

    # Per-department held-out classification comparison, based on the same test records.
    dept_rows = []
    jpred, nbpred = j48["pred_test"], nb["pred_test"]
    ytest = j48["y_test"]
    for dept in sorted(df["department"].unique()):
        idx = [i for i in ytest.index if df.loc[i, "department"] == dept]
        if len(idx) < 2:
            continue
        ydept = ytest.loc[idx]
        ja = accuracy_score(ydept, jpred.loc[idx])
        na = accuracy_score(ydept, nbpred.loc[idx])
        dept_rows.append({"Department": dept, "Test records": len(idx), "J48 accuracy": ja, "Naive Bayes accuracy": na,
                          "Best classification model": "J48" if ja >= na else "Naive Bayes"})
    department_comparison = pd.DataFrame(dept_rows)

    # The overall placement predictor recommendation compares only models built for classification.
    if j48["metrics"]["F1 score"] >= nb["metrics"]["F1 score"]:
        recommended = "J48 Decision Tree"
        reason = "It has the stronger held-out F1 score for the placement yes/no task (ties favor the more interpretable tree)."
    else:
        recommended = "Naive Bayes"
        reason = "It has the stronger held-out F1 score for the placement yes/no task on this dataset."
    return {"data": df, "j48": j48, "naive_bayes": nb, "regression": regression,
            "kmeans": kmeans, "apriori": apriori, "department_comparison": department_comparison,
            "recommended": recommended, "recommendation_reason": reason}


def train():
    """Backward-compatible J48 bundle for the existing placement predictor UI."""
    return train_all()["j48"]


def predict(bundle, profile):
    X = pd.DataFrame([profile])[FEATURES]
    pipe = bundle["pipe"]
    classes = list(pipe.classes_)
    proba = pipe.predict_proba(X)[0]
    p = float(proba[classes.index(1)]) if 1 in classes else 0.0
    return p >= 0.5, p
