"""Generate 60,000 synthetic placement records, deliberately including raw-data quality issues.
The raw CSV is for demonstrating data cleaning; do not treat synthetic records as real people.
"""
import numpy as np
import pandas as pd
from pathlib import Path
ROOT = Path(__file__).parent
CSV = ROOT / "data" / "placement_data.csv"
RAW_CSV = ROOT / "data" / "placement_data_uncleaned.csv"

def generate(n=60000, seed=42, dirty=True):
    rng = np.random.default_rng(seed)
    depts = np.array(["Computer Science", "Information Technology", "Electronics", "Mechanical", "Civil"])
    df = pd.DataFrame({
        "student_id": np.arange(1, n + 1),
        "gender": rng.choice(["Male", "Female", "Non-disclosed"], n, p=[.49,.49,.02]),
        "department": rng.choice(depts, n, p=[.30,.25,.20,.15,.10]),
        "cgpa": np.clip(rng.normal(7.4, 1.0, n), 4.5, 10).round(2),
        "internships": rng.choice([0,1,2,3], n, p=[.40,.35,.18,.07]),
        "projects": rng.integers(0, 6, n),
        "backlogs": rng.choice([0,1,2,3], n, p=[.70,.18,.08,.04]),
        "communication_score": rng.integers(1, 11, n),
    })
    bonus = df.department.map({"Computer Science":.8,"Information Technology":.6,"Electronics":.1,"Mechanical":-.3,"Civil":-.5})
    score = 1.1*(df.cgpa-7.2)+.7*df.internships+.2*df.projects-.6*df.backlogs+.25*(df.communication_score-7)+bonus+rng.normal(0,.6,n)
    df["placed"] = (rng.random(n) < 1/(1+np.exp(-score))).astype(int)
    pay = 3+(df.cgpa-6)*.9+df.internships*.6+bonus*1.5+rng.normal(0,.8,n)
    df["salary_lpa"] = np.where(df.placed==1, pay.clip(2.5).round(2), np.nan)
    if dirty:
        # Common realistic data-quality issues, intentionally confined to raw input.
        for col, frac in [("cgpa",.012),("internships",.008),("projects",.008),("communication_score",.008),("department",.006),("placed",.004)]:
            idx = rng.choice(df.index, max(1,int(n*frac)), replace=False)
            df.loc[idx,col] = np.nan
        idx = rng.choice(df.index, int(n*.004), replace=False); df.loc[idx,"cgpa"] = 12.7
        idx = rng.choice(df.index, int(n*.003), replace=False); df.loc[idx,"internships"] = -2
        idx = rng.choice(df.index, int(n*.003), replace=False); df.loc[idx,"department"] = "  "
        idx = rng.choice(df.index, int(n*.006), replace=False); df.loc[idx,"department"] = df.loc[idx,"department"].astype(str).str.lower().str.strip()+" "
        # Store several label variants that ETL should normalize.
        idx = rng.choice(df.index, int(n*.003), replace=False); df.loc[idx,"placed"] = "yes"
        idx = rng.choice(df.index, int(n*.003), replace=False); df.loc[idx,"placed"] = "no"
        # Duplicate IDs create a deduplication task.
        dup_idx = rng.choice(df.index[1:], int(n*.002), replace=False)
        df.loc[dup_idx,"student_id"] = df.loc[dup_idx-1,"student_id"].to_numpy()
        # Mixed numeric strings are a common CSV import issue.
        idx = rng.choice(df.index, int(n*.003), replace=False); df.loc[idx,"cgpa"] = df.loc[idx,"cgpa"].map(lambda x: "  "+str(x)+" ")
    return df

def main():
    CSV.parent.mkdir(exist_ok=True)
    raw = generate(60000, dirty=True)
    raw.to_csv(RAW_CSV,index=False)
    # The canonical input is intentionally uncleaned so ETL visibly cleans it on first run.
    raw.to_csv(CSV,index=False)
    print(f"Wrote {len(raw):,} raw records to {RAW_CSV} and {CSV}")

if __name__ == "__main__": main()
