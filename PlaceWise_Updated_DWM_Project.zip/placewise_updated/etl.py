"""ETL: CSV -> clean -> SQLite warehouse (star schema), plus SQL helper."""
import sqlite3
from contextlib import closing
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).parent
CSV = ROOT / "data" / "placement_data.csv"
DB = ROOT / "data" / "placewise.db"
REQUIRED = ["student_id", "department", "cgpa", "internships", "projects",
            "backlogs", "communication_score", "placed"]
COUNTS = ["internships", "projects", "backlogs", "communication_score"]
PLACED_MAP = {"1": 1, "1.0": 1, "yes": 1, "placed": 1, "true": 1, "0": 0, "0.0": 0, "no": 0, "not placed": 0, "false": 0}

def extract(csv=CSV):
    if not Path(csv).exists():
        from generate_data import main
        main()
    return pd.read_csv(csv)

def transform(df):
    df = df.copy()
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    missing = set(REQUIRED) - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing columns: {sorted(missing)}")
    df = df.drop_duplicates("student_id")
    df["department"] = df["department"].astype("string").str.strip().str.title()
    df["department"] = df["department"].replace({"": pd.NA, "Nan": pd.NA, "None": pd.NA})
    df["cgpa"] = pd.to_numeric(df["cgpa"], errors="coerce")
    df = df.dropna(subset=["cgpa", "department"])
    df["cgpa"] = df["cgpa"].where(df["cgpa"].between(0, 10))
    df = df.dropna(subset=["cgpa", "department"])
    for c in COUNTS:
        s = pd.to_numeric(df[c], errors="coerce")
        s = s.where(s >= 0)
        if c == "communication_score": s = s.where(s <= 10)
        df[c] = s.fillna(s.median()).round().astype(int)
    df["placed"] = df["placed"].astype("string").str.strip().str.lower().map(PLACED_MAP)
    df = df.dropna(subset=["placed"])
    df["placed"] = df["placed"].astype(int)
    df = df[df["department"].astype(str).str.strip().ne("")].copy()
    if "salary_lpa" not in df:
        df["salary_lpa"] = np.nan
    df["salary_lpa"] = pd.to_numeric(df["salary_lpa"], errors="coerce")
    df.loc[df["placed"] == 0, "salary_lpa"] = np.nan
    if "gender" not in df:
        df["gender"] = "Unknown"
    return df.reset_index(drop=True)

def load(df, db=DB):
    Path(db).parent.mkdir(exist_ok=True)
    with closing(sqlite3.connect(db)) as con:
        con.executescript("""DROP VIEW IF EXISTS vw_students;
                             DROP TABLE IF EXISTS fact_students;
                             DROP TABLE IF EXISTS dim_department;""")
        dim = pd.DataFrame({"department": sorted(df["department"].unique())})
        dim.insert(0, "dept_id", range(1, len(dim) + 1))
        dim.to_sql("dim_department", con, index=False)
        fact = df.merge(dim, on="department").drop(columns="department")
        fact.to_sql("fact_students", con, index=False)
        con.execute("""CREATE VIEW vw_students AS
                       SELECT f.*, d.department FROM fact_students f
                       JOIN dim_department d USING (dept_id)""")
        con.commit()

def run_etl():
    raw = extract()
    clean = transform(raw)
    load(clean)
    return {"raw_rows": len(raw), "clean_rows": len(clean)}

def query(sql, params=()):
    with closing(sqlite3.connect(DB)) as con:
        return pd.read_sql_query(sql, con, params=params)

if __name__ == "__main__":
    print(run_etl())
