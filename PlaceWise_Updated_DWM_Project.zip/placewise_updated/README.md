# PlaceWise — DWDM Student Placement Analytics

PlaceWise is a Streamlit mini-project demonstrating a data warehouse and data-mining pipeline for student placement analysis.

## Included modules
- ETL pipeline: raw CSV -> validation/cleaning -> SQLite warehouse.
- J48-style entropy decision tree and Naive Bayes placement classifiers.
- Multiple Linear Regression for salary estimation (R², MAE, RMSE).
- K-Means clustering for student profile segmentation (silhouette score).
- Apriori-style association rules (support, confidence, lift).
- A single-window **Compare: J48 vs Naive Bayes** dashboard that also includes regression and clustering, definitions, classification metrics, a tree diagram, model graphs, and task-specific metrics.
- Department-wise classification comparison and an interactive placement predictor.

## Dataset
The project generates **60,000 synthetic student records**. It deliberately includes data-quality issues in `data/placement_data_uncleaned.csv` and `data/placement_data.csv` (missing values, duplicate IDs, inconsistent department strings, label variants, out-of-range CGPA, and negative counts). The ETL pipeline cleans and loads records into `data/placewise.db`. The current synthetic run retains approximately 58,000 clean rows. These are fictional demonstration records, not real people.

To regenerate the raw dataset and rebuild the warehouse:
```bash
python generate_data.py
python etl.py
```

## Setup (Windows)
Use Python 3.11 or 3.12 if your Windows application-control policy blocks compiled Python packages in newer runtimes. From the project folder:
```bat
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
streamlit run app.py
```

## Dataset columns
`student_id`, `gender`, `department`, `cgpa`, `internships`, `projects`, `backlogs`, `communication_score`, `placed`, `salary_lpa`.

## How to interpret comparison
Accuracy, precision, recall and F1 are valid for J48 and Naive Bayes classification. They are **not applicable** to salary regression or unsupervised K-Means clustering. Regression is evaluated with R²/MAE/RMSE; clustering uses silhouette score. Apriori uses support/confidence/lift. Do not compare these unlike scores as if they measured the same task.

**Implementation note:** the tree is an entropy-based J48-style tree using scikit-learn; it is not the exact WEKA J48 implementation.
